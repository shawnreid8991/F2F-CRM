import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv

db = SQLAlchemy()

def create_app():
    load_dotenv()
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-secret-change-me")

    # Prefer DATABASE_URL (Render Postgres). Fall back to local SQLite.
    database_url = os.getenv("DATABASE_URL")
    if database_url:
        # Render sometimes gives postgres:// — SQLAlchemy needs postgresql://
        if database_url.startswith("postgres://"):
            database_url = database_url.replace("postgres://", "postgresql://", 1)
        app.config["SQLALCHEMY_DATABASE_URI"] = database_url
    else:
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        db_path = os.path.join(base_dir, "data", "crm.db")
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{db_path}"

    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)

    # Register core blueprints
    from app.modules.contacts import contacts_bp
    from app.modules.deals import deals_bp
    from app.modules.activities import activities_bp
    from app.modules.products import products_bp
    from app.modules.dashboard import dashboard_bp

    app.register_blueprint(dashboard_bp)
    app.register_blueprint(contacts_bp, url_prefix="/contacts")
    app.register_blueprint(deals_bp, url_prefix="/deals")
    app.register_blueprint(activities_bp, url_prefix="/activities")
    app.register_blueprint(products_bp, url_prefix="/products")

    with app.app_context():
        db.create_all()
        # Seed a few default products if empty
        from app.modules.products.models import Product
        if Product.query.count() == 0:
            defaults = [
                Product(name="Basic Service Package", price=499.00, category="Service"),
                Product(name="Premium Consultation", price=1299.00, category="Service"),
                Product(name="Starter Kit", price=89.00, category="Product"),
            ]
            db.session.add_all(defaults)
            db.session.commit()

    return app
