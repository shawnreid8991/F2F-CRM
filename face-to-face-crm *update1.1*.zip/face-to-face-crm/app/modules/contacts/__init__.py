from flask import Blueprint, render_template, request, redirect, url_for, flash
from app import db
from .models import Contact

contacts_bp = Blueprint("contacts", __name__, template_folder="../../templates")

@contacts_bp.route("/")
def list_contacts():
    status = request.args.get("status")
    q = request.args.get("q", "").strip()
    query = Contact.query
    if status:
        query = query.filter_by(status=status)
    if q:
        like = f"%{q}%"
        query = query.filter(
            db.or_(
                Contact.first_name.ilike(like),
                Contact.last_name.ilike(like),
                Contact.company.ilike(like),
                Contact.email.ilike(like),
                Contact.phone.ilike(like),
            )
        )
    contacts = query.order_by(Contact.updated_at.desc()).all()
    return render_template("contacts/list.html", contacts=contacts, status=status, q=q)


@contacts_bp.route("/new", methods=["GET", "POST"])
def new_contact():
    if request.method == "POST":
        contact = Contact(
            first_name=request.form["first_name"].strip(),
            last_name=request.form["last_name"].strip(),
            email=request.form.get("email", "").strip() or None,
            phone=request.form.get("phone", "").strip() or None,
            company=request.form.get("company", "").strip() or None,
            job_title=request.form.get("job_title", "").strip() or None,
            status=request.form.get("status", "Lead"),
            source=request.form.get("source", "").strip() or None,
            tags=request.form.get("tags", "").strip() or None,
            notes=request.form.get("notes", "").strip() or None,
            address=request.form.get("address", "").strip() or None,
            city=request.form.get("city", "").strip() or None,
            preferred_contact=request.form.get("preferred_contact", "In-person"),
        )
        db.session.add(contact)
        db.session.commit()
        flash("Contact created.", "success")
        return redirect(url_for("contacts.view_contact", contact_id=contact.id))
    return render_template("contacts/form.html", contact=None)


@contacts_bp.route("/<int:contact_id>")
def view_contact(contact_id):
    contact = Contact.query.get_or_404(contact_id)
    return render_template("contacts/view.html", contact=contact)


@contacts_bp.route("/<int:contact_id>/edit", methods=["GET", "POST"])
def edit_contact(contact_id):
    contact = Contact.query.get_or_404(contact_id)
    if request.method == "POST":
        contact.first_name = request.form["first_name"].strip()
        contact.last_name = request.form["last_name"].strip()
        contact.email = request.form.get("email", "").strip() or None
        contact.phone = request.form.get("phone", "").strip() or None
        contact.company = request.form.get("company", "").strip() or None
        contact.job_title = request.form.get("job_title", "").strip() or None
        contact.status = request.form.get("status", "Lead")
        contact.source = request.form.get("source", "").strip() or None
        contact.tags = request.form.get("tags", "").strip() or None
        contact.notes = request.form.get("notes", "").strip() or None
        contact.address = request.form.get("address", "").strip() or None
        contact.city = request.form.get("city", "").strip() or None
        contact.preferred_contact = request.form.get("preferred_contact", "In-person")
        db.session.commit()
        flash("Contact updated.", "success")
        return redirect(url_for("contacts.view_contact", contact_id=contact.id))
    return render_template("contacts/form.html", contact=contact)


@contacts_bp.route("/<int:contact_id>/delete", methods=["POST"])
def delete_contact(contact_id):
    contact = Contact.query.get_or_404(contact_id)
    db.session.delete(contact)
    db.session.commit()
    flash("Contact deleted.", "success")
    return redirect(url_for("contacts.list_contacts"))