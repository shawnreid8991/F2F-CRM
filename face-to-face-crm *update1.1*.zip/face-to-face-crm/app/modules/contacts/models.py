from app import db
from app.models_base import TimestampMixin

class Contact(db.Model, TimestampMixin):
    __tablename__ = "contacts"

    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120))
    phone = db.Column(db.String(40))
    company = db.Column(db.String(120))
    job_title = db.Column(db.String(100))
    status = db.Column(db.String(40), default="Lead")  # Lead, Prospect, Customer, Inactive
    source = db.Column(db.String(80))  # Walk-in, Referral, Event, Cold, etc.
    tags = db.Column(db.String(255))  # comma-separated
    notes = db.Column(db.Text)
    address = db.Column(db.String(255))
    city = db.Column(db.String(80))
    preferred_contact = db.Column(db.String(40), default="In-person")

    deals = db.relationship("Deal", back_populates="contact", lazy="dynamic")
    activities = db.relationship(
        "Activity",
        back_populates="contact",
        lazy="dynamic",
        order_by="desc(Activity.activity_date)",
    )

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"

    def __repr__(self):
        return f"<Contact {self.full_name}>"