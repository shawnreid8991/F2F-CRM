from flask import Blueprint, render_template
from datetime import datetime, timedelta
from app import db
from app.modules.contacts.models import Contact
from app.modules.deals.models import Deal
from app.modules.activities.models import Activity

dashboard_bp = Blueprint("dashboard", __name__, template_folder="../../templates")

@dashboard_bp.route("/")
def index():
    total_contacts = Contact.query.count()
    leads = Contact.query.filter_by(status="Lead").count()
    customers = Contact.query.filter_by(status="Customer").count()
    open_deals = Deal.query.filter(Deal.stage.notin_(["Won", "Lost"])).count()
    pipeline_value = (
        db.session.query(db.func.coalesce(db.func.sum(Deal.value), 0))
        .filter(Deal.stage.notin_(["Won", "Lost"]))
        .scalar()
    )
    won_value = (
        db.session.query(db.func.coalesce(db.func.sum(Deal.value), 0))
        .filter_by(stage="Won")
        .scalar()
    )

    # Upcoming / recent activities
    today = datetime.utcnow().date()
    upcoming = (
        Activity.query.filter(Activity.next_action_date >= today)
        .order_by(Activity.next_action_date)
        .limit(8)
        .all()
    )
    recent_activities = (
        Activity.query.order_by(Activity.activity_date.desc()).limit(8).all()
    )
    recent_contacts = Contact.query.order_by(Contact.updated_at.desc()).limit(5).all()

    return render_template(
        "dashboard.html",
        total_contacts=total_contacts,
        leads=leads,
        customers=customers,
        open_deals=open_deals,
        pipeline_value=pipeline_value or 0,
        won_value=won_value or 0,
        upcoming=upcoming,
        recent_activities=recent_activities,
        recent_contacts=recent_contacts,
    )