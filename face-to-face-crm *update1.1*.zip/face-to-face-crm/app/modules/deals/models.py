from app import db
from app.models_base import TimestampMixin

class Deal(db.Model, TimestampMixin):
    __tablename__ = "deals"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    contact_id = db.Column(db.Integer, db.ForeignKey("contacts.id"), nullable=False)
    stage = db.Column(db.String(40), default="Qualification")  
    # Qualification, Proposal, Negotiation, Won, Lost
    value = db.Column(db.Float, default=0.0)
    probability = db.Column(db.Integer, default=20)  # 0-100
    expected_close = db.Column(db.Date)
    notes = db.Column(db.Text)
    product_ids = db.Column(db.String(255))  # simple comma-separated product ids

    contact = db.relationship("Contact", back_populates="deals")

    def __repr__(self):
        return f"<Deal {self.title}>"