from flask import Blueprint, render_template, request, redirect, url_for, flash
from datetime import datetime
from app import db
from .models import Deal
from app.modules.contacts.models import Contact
from app.modules.products.models import Product

deals_bp = Blueprint("deals", __name__, template_folder="../../templates")

STAGES = ["Qualification", "Proposal", "Negotiation", "Won", "Lost"]

@deals_bp.route("/")
def list_deals():
    stage = request.args.get("stage")
    query = Deal.query
    if stage:
        query = query.filter_by(stage=stage)
    deals = query.order_by(Deal.updated_at.desc()).all()
    return render_template("deals/list.html", deals=deals, stages=STAGES, current_stage=stage)


@deals_bp.route("/new", methods=["GET", "POST"])
def new_deal():
    contacts = Contact.query.order_by(Contact.last_name).all()
    products = Product.query.order_by(Product.name).all()
    if request.method == "POST":
        expected = request.form.get("expected_close") or None
        if expected:
            expected = datetime.strptime(expected, "%Y-%m-%d").date()
        product_ids = ",".join(request.form.getlist("products"))
        deal = Deal(
            title=request.form["title"].strip(),
            contact_id=int(request.form["contact_id"]),
            stage=request.form.get("stage", "Qualification"),
            value=float(request.form.get("value") or 0),
            probability=int(request.form.get("probability") or 20),
            expected_close=expected,
            notes=request.form.get("notes", "").strip() or None,
            product_ids=product_ids or None,
        )
        db.session.add(deal)
        db.session.commit()
        flash("Deal created.", "success")
        return redirect(url_for("deals.view_deal", deal_id=deal.id))
    return render_template("deals/form.html", deal=None, contacts=contacts, products=products, stages=STAGES)


@deals_bp.route("/<int:deal_id>")
def view_deal(deal_id):
    deal = Deal.query.get_or_404(deal_id)
    products = []
    if deal.product_ids:
        ids = [int(x) for x in deal.product_ids.split(",") if x.strip().isdigit()]
        products = Product.query.filter(Product.id.in_(ids)).all()
    return render_template("deals/view.html", deal=deal, products=products)


@deals_bp.route("/<int:deal_id>/edit", methods=["GET", "POST"])
def edit_deal(deal_id):
    deal = Deal.query.get_or_404(deal_id)
    contacts = Contact.query.order_by(Contact.last_name).all()
    products = Product.query.order_by(Product.name).all()
    if request.method == "POST":
        expected = request.form.get("expected_close") or None
        if expected:
            expected = datetime.strptime(expected, "%Y-%m-%d").date()
        deal.title = request.form["title"].strip()
        deal.contact_id = int(request.form["contact_id"])
        deal.stage = request.form.get("stage", "Qualification")
        deal.value = float(request.form.get("value") or 0)
        deal.probability = int(request.form.get("probability") or 20)
        deal.expected_close = expected
        deal.notes = request.form.get("notes", "").strip() or None
        deal.product_ids = ",".join(request.form.getlist("products")) or None
        db.session.commit()
        flash("Deal updated.", "success")
        return redirect(url_for("deals.view_deal", deal_id=deal.id))
    selected_products = []
    if deal.product_ids:
        selected_products = [int(x) for x in deal.product_ids.split(",") if x.strip().isdigit()]
    return render_template(
        "deals/form.html",
        deal=deal,
        contacts=contacts,
        products=products,
        stages=STAGES,
        selected_products=selected_products,
    )


@deals_bp.route("/<int:deal_id>/delete", methods=["POST"])
def delete_deal(deal_id):
    deal = Deal.query.get_or_404(deal_id)
    db.session.delete(deal)
    db.session.commit()
    flash("Deal deleted.", "success")
    return redirect(url_for("deals.list_deals"))