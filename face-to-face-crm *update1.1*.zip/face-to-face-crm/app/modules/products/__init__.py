from flask import Blueprint, render_template, request, redirect, url_for, flash
from app import db
from .models import Product

products_bp = Blueprint("products", __name__, template_folder="../../templates")

@products_bp.route("/")
def list_products():
    products = Product.query.order_by(Product.name).all()
    return render_template("products/list.html", products=products)


@products_bp.route("/new", methods=["GET", "POST"])
def new_product():
    if request.method == "POST":
        product = Product(
            name=request.form["name"].strip(),
            description=request.form.get("description", "").strip() or None,
            price=float(request.form.get("price") or 0),
            category=request.form.get("category", "").strip() or None,
            sku=request.form.get("sku", "").strip() or None,
            active=bool(request.form.get("active")),
        )
        db.session.add(product)
        db.session.commit()
        flash("Product created.", "success")
        return redirect(url_for("products.list_products"))
    return render_template("products/form.html", product=None)


@products_bp.route("/<int:product_id>/edit", methods=["GET", "POST"])
def edit_product(product_id):
    product = Product.query.get_or_404(product_id)
    if request.method == "POST":
        product.name = request.form["name"].strip()
        product.description = request.form.get("description", "").strip() or None
        product.price = float(request.form.get("price") or 0)
        product.category = request.form.get("category", "").strip() or None
        product.sku = request.form.get("sku", "").strip() or None
        product.active = bool(request.form.get("active"))
        db.session.commit()
        flash("Product updated.", "success")
        return redirect(url_for("products.list_products"))
    return render_template("products/form.html", product=product)


@products_bp.route("/<int:product_id>/delete", methods=["POST"])
def delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    flash("Product deleted.", "success")
    return redirect(url_for("products.list_products"))