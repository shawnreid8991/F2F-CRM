from app import db
from app.models_base import TimestampMixin

class Product(db.Model, TimestampMixin):
    __tablename__ = "products"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, default=0.0)
    category = db.Column(db.String(80))
    sku = db.Column(db.String(40))
    active = db.Column(db.Boolean, default=True)

    def __repr__(self):
        return f"<Product {self.name}>"