from flask import Blueprint, render_template, request, redirect, url_for, flash
from datetime import datetime
from app import db
from .models import Activity
from app.modules.contacts.models import Contact

activities_bp = Blueprint("activities", __name__, template_folder="../../templates")

ACTIVITY_TYPES = ["Meeting", "Visit", "Call", "Demo", "Follow-up", "Other"]
OUTCOMES = ["Positive", "Neutral", "Needs follow-up", "Closed", "No show"]

@activities_bp.route("/")
def list_activities():
    contact_id = request.args.get("contact_id", type=int)
    query = Activity.query
    if contact_id:
        query = query.filter_by(contact_id=contact_id)
    activities = query.order_by(Activity.activity_date.desc()).limit(100).all()
    return render_template("activities/list.html", activities=activities)


@activities_bp.route("/new", methods=["GET", "POST"])
def new_activity():
    contacts = Contact.query.order_by(Contact.last_name).all()
    preselect = request.args.get("contact_id", type=int)
    if request.method == "POST":
        act_date = request.form.get("activity_date")
        act_time = request.form.get("activity_time") or "09:00"
        dt = datetime.strptime(f"{act_date} {act_time}", "%Y-%m-%d %H:%M")
        next_date = request.form.get("next_action_date") or None
        if next_date:
            next_date = datetime.strptime(next_date, "%Y-%m-%d").date()
        activity = Activity(
            contact_id=int(request.form["contact_id"]),
            activity_type=request.form["activity_type"],
            subject=request.form["subject"].strip(),
            description=request.form.get("description", "").strip() or None,
            activity_date=dt,
            location=request.form.get("location", "").strip() or None,
            duration_minutes=int(request.form.get("duration_minutes") or 0) or None,
            outcome=request.form.get("outcome") or None,
            next_action=request.form.get("next_action", "").strip() or None,
            next_action_date=next_date,
        )
        db.session.add(activity)
        db.session.commit()
        flash("Activity logged.", "success")
        return redirect(url_for("activities.list_activities"))
    return render_template(
        "activities/form.html",
        activity=None,
        contacts=contacts,
        activity_types=ACTIVITY_TYPES,
        outcomes=OUTCOMES,
        preselect=preselect,
    )


@activities_bp.route("/<int:activity_id>/edit", methods=["GET", "POST"])
def edit_activity(activity_id):
    activity = Activity.query.get_or_404(activity_id)
    contacts = Contact.query.order_by(Contact.last_name).all()
    if request.method == "POST":
        act_date = request.form.get("activity_date")
        act_time = request.form.get("activity_time") or "09:00"
        dt = datetime.strptime(f"{act_date} {act_time}", "%Y-%m-%d %H:%M")
        next_date = request.form.get("next_action_date") or None
        if next_date:
            next_date = datetime.strptime(next_date, "%Y-%m-%d").date()
        activity.contact_id = int(request.form["contact_id"])
        activity.activity_type = request.form["activity_type"]
        activity.subject = request.form["subject"].strip()
        activity.description = request.form.get("description", "").strip() or None
        activity.activity_date = dt
        activity.location = request.form.get("location", "").strip() or None
        activity.duration_minutes = int(request.form.get("duration_minutes") or 0) or None
        activity.outcome = request.form.get("outcome") or None
        activity.next_action = request.form.get("next_action", "").strip() or None
        activity.next_action_date = next_date
        db.session.commit()
        flash("Activity updated.", "success")
        return redirect(url_for("activities.list_activities"))
    return render_template(
        "activities/form.html",
        activity=activity,
        contacts=contacts,
        activity_types=ACTIVITY_TYPES,
        outcomes=OUTCOMES,
        preselect=None,
    )


@activities_bp.route("/<int:activity_id>/delete", methods=["POST"])
def delete_activity(activity_id):
    activity = Activity.query.get_or_404(activity_id)
    db.session.delete(activity)
    db.session.commit()
    flash("Activity deleted.", "success")
    return redirect(url_for("activities.list_activities"))