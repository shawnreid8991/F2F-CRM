from app import db
from app.models_base import TimestampMixin

class Activity(db.Model, TimestampMixin):
    __tablename__ = "activities"

    id = db.Column(db.Integer, primary_key=True)
    contact_id = db.Column(db.Integer, db.ForeignKey("contacts.id"), nullable=False)
    activity_type = db.Column(db.String(40), nullable=False)  
    # Meeting, Visit, Call, Demo, Follow-up, Other
    subject = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    activity_date = db.Column(db.DateTime, nullable=False)
    location = db.Column(db.String(150))  # important for face-to-face
    duration_minutes = db.Column(db.Integer)
    outcome = db.Column(db.String(80))  # Positive, Neutral, Needs follow-up, Closed
    next_action = db.Column(db.String(255))
    next_action_date = db.Column(db.Date)

    contact = db.relationship("Contact", back_populates="activities")

    def __repr__(self):
        return f"<Activity {self.subject}>"