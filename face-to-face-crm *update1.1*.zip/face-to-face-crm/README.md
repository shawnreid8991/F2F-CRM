# Face-to-Face Sales CRM

A basic, **modularly customizable** CRM built specifically for face-to-face / in-person selling.

## Features

| Module | What it does |
|--------|--------------|
| **Dashboard** | Overview of contacts, pipeline value, upcoming follow-ups, recent activity |
| **Contacts** | Leads → Prospects → Customers. Source, tags, preferred contact method, location |
| **Deals** | Simple pipeline (Qualification → Proposal → Negotiation → Won/Lost) with value & probability |
| **Activities** | Log Meetings, Visits, Demos, Calls. Location field is first-class for F2F |
| **Products** | Lightweight catalog of what you sell in person |

### Face-to-face oriented design
- Location is a first-class field on every activity
- Preferred contact method defaults to "In-person"
- Source tracking (Walk-in, Referral, Event, Cold, etc.)
- Quick "Log Activity" from contact view
- Next-action + next-action-date for follow-up discipline

## Modular architecture

Each domain lives in its own package under `app/modules/`:

```
app/modules/
├── contacts/     # models + routes
├── deals/
├── activities/
├── products/
└── dashboard/
```

To add a new module:
1. Create `app/modules/yourmodule/` with `models.py` and `__init__.py` (Blueprint)
2. Register the blueprint in `app/__init__.py`
3. Add templates under `app/templates/yourmodule/`

You can disable a module simply by not registering its blueprint.

## Quick start

```bash
cd face-to-face-crm
python3 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
python run.py
```

Open http://127.0.0.1:5000

Database is SQLite (`data/crm.db`) — created automatically on first run. A few sample products are seeded.

## Tech stack

- Python 3 + Flask
- SQLAlchemy + SQLite
- Tailwind CSS (CDN) for a clean modern UI
- No auth out of the box (single-user / local tool). Easy to add Flask-Login later.

## Customization ideas

- Add multi-user + roles
- Attach photos / business cards to contacts or activities
- Geolocation / map view of visits
- Simple reporting (conversion rates, activity volume)
- Export to CSV
- Mobile-friendly progressive web app wrapper

Built to be simple, readable, and easy to extend for real-world face-to-face sales teams.